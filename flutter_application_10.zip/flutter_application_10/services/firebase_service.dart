import 'package:cloud_firestore/cloud_firestore.dart';

// Creamos la variable db, de tipo FirebaseFirestore
FirebaseFirestore db = FirebaseFirestore.instance;

// Creamos un Future que nos traerá los registros (documentos) almacenados en Firebase Firestore Database
Future<List<Map<String, dynamic>>> getUsuarios() async {
  // Creamos la variable usuarios de tipo List para recibir los registros
  List<Map<String, dynamic>> usuarios = [];

  try {
    // Referencia a la colección "usuarios"
    CollectionReference collectionReferenceUsuarios = db.collection('usuarios');

    // Obtenemos los documentos de la colección
    QuerySnapshot queryUsuarios = await collectionReferenceUsuarios.get();

    // Iteramos sobre los documentos y los añadimos a la lista
    for (var documento in queryUsuarios.docs) {
      usuarios.add(documento.data() as Map<String, dynamic>);
    }
  } catch (e) {
    // Imprimimos el error en caso de fallo
    print('Error al obtener los usuarios: $e');
  }

  // Devolvemos la lista de usuarios
  return usuarios;
}
