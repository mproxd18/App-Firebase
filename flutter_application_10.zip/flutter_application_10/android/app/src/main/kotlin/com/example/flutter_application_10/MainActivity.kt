package com.example.flutter_application_10

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
