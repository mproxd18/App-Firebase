import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: const Home(),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Future<List<Map<String, dynamic>>> getUsuarios() async {
    // Simula una consulta a la base de datos
    await Future.delayed(const Duration(seconds: 2));
    return [
      {'nombre': 'Juan', 'aPaterno': 'Pérez'},
      {'nombre': 'María', 'aPaterno': 'Gómez'},
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: getUsuarios(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text('No se encontraron usuarios.'),
            );
          }

          return ListView.builder(
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final usuario = snapshot.data![index];
              return ListTile(
                title: Text(usuario['nombre'] ?? 'Sin nombre'),
                subtitle: Text(usuario['aPaterno'] ?? 'Sin apellido'),
                leading: CircleAvatar(
                  child: Text(
                    (usuario['nombre'] ?? '?').substring(0, 1).toUpperCase(),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}


